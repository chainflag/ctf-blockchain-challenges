# Supply
This module is copied from `cosmos-sdk/x/supply` folder, the only modification is adding `SetModuleAddressAndPermissions` method in keeper.