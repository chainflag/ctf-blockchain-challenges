# billboard

**billboard** is a blockchain application built using Cosmos SDK and Tendermint.

## Get started

```
make all
bash script/start_testnet.sh
```
